// import '../styles/globals.css'
import "../styles/staking-a.css"
import "../styles/styles-c.css"
import "../styles/leaderboard-a.css"
import "../styles/shop-a.css"

function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export default MyApp
